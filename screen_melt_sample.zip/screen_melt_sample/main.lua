composer = require('composer')
require('plugin.screenMelt')

centerX = display.contentCenterX
centerY = display.contentCenterY
screenTop = math.floor(display.screenOriginY)
screenBottom = math.ceil(display.contentHeight - screenTop)
screenHeight = screenBottom - screenTop
screenLeft = math.floor(display.screenOriginX)
screenRight = math.ceil(display.contentWidth - screenLeft)
screenWidth = screenRight - screenLeft

local label = display.newEmbossedText({
  parent = display.currentStage,
  text = 'SchroederApps ScreenMelt Demo\n(tap to advance)',
  fontSize = 72,
  x = centerX,
  y = centerY,
  width = screenWidth,
  align = 'center'
})
label.alpha = .8

composer.gotoScene('scenes.scene1')
