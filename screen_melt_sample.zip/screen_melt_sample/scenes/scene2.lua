--------------------------------------------------------------------------------
-- INITIALIZE SCENE & LOAD LIBRARIES
--------------------------------------------------------------------------------
local scene = composer.newScene()
local group, bg
local physics = require('physics')
physics.start()

local function swapScenes()
  composer.gotoScene('scenes.scene3', 'screenMelt')
end

local function throwBox()
  if group == nil or group.removeSelf == nil then return true end
  local box = display.newRect(group, math.random(screenLeft, screenRight), screenTop - 100, math.random(50, 95), math.random(50, 95))
  box:setFillColor(math.random(), math.random(), math.random())
  physics.addBody(box)
  box:applyForce(math.random(-2, 2), math.random(-1,1))
  timer.performWithDelay(100, throwBox)
end

--------------------------------------------------------------------------------
-- CREATE SCENE
--------------------------------------------------------------------------------
function scene:create( event )
	group = self.view

  bg = display.newRect(group, centerX, centerY, screenWidth, screenHeight)
  bg.r, bg.g, bg.b = math.random(), math.random(), math.random()
  bg.r_direction = 1
  bg.g_direction = 1
  bg.b_direction = 1

  function bg.enterFrame(self)
    local function adjust_color(c)
      self[c] = self[c] + math.random()*.005 * self[c .. '_direction']
      if self[c] >= 1 then
        self[c..'_direction'] = -1
      elseif self[c] <= 0 then
        self[c..'_direction'] = 1
      end
    end

    adjust_color('r')
    adjust_color('g')
    adjust_color('b')

    self:setFillColor(self.r, self.g, self.b)
  end

  local eraser = display.newRect(group, centerX, screenBottom, screenWidth * 3, 50)
  eraser.anchorY = 0
  physics.addBody(eraser, 'static')
  local function onCollision(event)
    display.remove(event.other)
  end
  eraser:addEventListener('collision', onCollision)

  bg:addEventListener('tap', swapScenes)
  throwBox()
end

--------------------------------------------------------------------------------
-- SHOW SCENE
--------------------------------------------------------------------------------
function scene:show( event )
	----------------------------------------
	-- WILL SHOW
	----------------------------------------
	if event.phase=="will" then

	----------------------------------------
	-- DID SHOW
	----------------------------------------
	elseif event.phase=="did" then
    Runtime:addEventListener('enterFrame', bg)
	end
end

--------------------------------------------------------------------------------
-- HIDE SCENE
--------------------------------------------------------------------------------
function scene:hide( event )
	----------------------------------------
	-- WILL HIDE
	----------------------------------------
	if event.phase=="will" then

	----------------------------------------
	-- DID HIDE
	----------------------------------------
	elseif event.phase=="did" then

	end
end

--------------------------------------------------------------------------------
-- DESTROY SCENE
--------------------------------------------------------------------------------
function scene:destroy( event )

end

--------------------------------------------------------------------------------
-- COMPOSER LISTENERS
--------------------------------------------------------------------------------
scene:addEventListener( "create", scene )
scene:addEventListener( "show", scene )
scene:addEventListener( "hide", scene )
scene:addEventListener( "destroy", scene )

return scene
