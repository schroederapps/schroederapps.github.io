--------------------------------------------------------------------------------
-- INITIALIZE SCENE & LOAD LIBRARIES
--------------------------------------------------------------------------------
local scene = composer.newScene()

local function swapScenes()
  composer.gotoScene('scenes.scene4', {effect = 'screenMelt'})
end

--------------------------------------------------------------------------------
-- CREATE SCENE
--------------------------------------------------------------------------------
function scene:create( event )
	group = self.view

  local img = display.newImage(group, 'images/doom2.jpg')
  local s = screenHeight / img.height
  if s * img.width < screenWidth then s = screenWidth / img.width end
  img.xScale, img.yScale = s, s
  img.x, img.y = centerX, centerY

  img:addEventListener('tap', swapScenes)

end

--------------------------------------------------------------------------------
-- SHOW SCENE
--------------------------------------------------------------------------------
function scene:show( event )
	----------------------------------------
	-- WILL SHOW
	----------------------------------------
	if event.phase=="will" then

	----------------------------------------
	-- DID SHOW
	----------------------------------------
	elseif event.phase=="did" then

	end
end

--------------------------------------------------------------------------------
-- HIDE SCENE
--------------------------------------------------------------------------------
function scene:hide( event )
	----------------------------------------
	-- WILL HIDE
	----------------------------------------
	if event.phase=="will" then

	----------------------------------------
	-- DID HIDE
	----------------------------------------
	elseif event.phase=="did" then

	end
end

--------------------------------------------------------------------------------
-- DESTROY SCENE
--------------------------------------------------------------------------------
function scene:destroy( event )

end

--------------------------------------------------------------------------------
-- COMPOSER LISTENERS
--------------------------------------------------------------------------------
scene:addEventListener( "create", scene )
scene:addEventListener( "show", scene )
scene:addEventListener( "hide", scene )
scene:addEventListener( "destroy", scene )

return scene
