--------------------------------------------------------------------------------
-- REQUIRE & INITIALIZE STRIPE PLUGIN
--------------------------------------------------------------------------------
local stripe = require("plugin.stripe")
stripe.init({
    secretKey = "enterYourSecretKeyHere",
    publishableKey = "enterYourPublishableKeyHere",
})

--------------------------------------------------------------------------------
-- STRIPE IDs TO TEST FUNCTIONS
--------------------------------------------------------------------------------
local getChargeID = ""
local updateChargeID = ""
local captureChargeID = ""
local getCustomerID = ""
local updateCustomerID = ""
local deleteCustomerID = ""
local getTokenID = ""
local donateAmount = 300

--------------------------------------------------------------------------------
-- LET'S CREATE SOME LOCAL VARIABLES:
--------------------------------------------------------------------------------
local centerX = display.contentCenterX
local centerY = display.contentCenterY
local screenTop = math.floor(display.screenOriginY)
local screenLeft = math.floor(display.screenOriginX)
local screenBottom = display.contentHeight - screenTop
local screenRight = display.contentWidth - screenLeft
local screenWidth = screenRight - screenLeft
local screenHeight = screenBottom - screenTop

local fontAwesome = require("fontAwesome")
local widget = require("widget")
local background, foreground, bg, stripeLogo, byline, cards, scrollView, showButtons, hideButtons, makeButton
local checkout, newCharge, getCharge, updateCharge, captureCharge, listCharges, newCustomer, getCustomer, updateCustomer, deleteCustomer, listCustomers, newToken, getToken, _onSuccess, _onFail, donate, noData
local buttons = {}


--------------------------------------------------------------------------------
-- CONVERT TABLE TO STRING
--------------------------------------------------------------------------------
function tableToString ( t )
	local output = {}
    local print_r_cache={}
    local function sub_print_r(t,indent)
    	local function print(string)
    		output[#output + 1] = string
    	end
        if (print_r_cache[tostring(t)]) then
            print(indent.."*"..tostring(t))
        else
            print_r_cache[tostring(t)]=true
            if (type(t)=="table") then
                for pos,val in pairs(t) do
                    if (type(val)=="table") then
                        print(indent.."["..pos.."] => "..tostring(t).." {")
                        sub_print_r(val,indent..string.rep(" ",string.len(pos)+8))
                        print(indent..string.rep(" ",string.len(pos)+6).."}")
                    elseif (type(val)=="string") then
                        print(indent.."["..pos..'] => "'..val..'"')
                    else
                        print(indent.."["..pos.."] => "..tostring(val))
                    end
                end
            else
                print(indent..tostring(t))
            end
        end
    end

	sub_print_r(t,"  ")

    return output
end

--------------------------------------------------------------------------------
-- DISPLAY RESULTS IN SCROLLVIEW
--------------------------------------------------------------------------------
function showResults(results, isSuccess)
    hideButtons()
    local results = tableToString(results)

    local headerStatement = "TRANSACTION SUCCEEDED!\nA Stripe object table was returned to the 'onSuccess' listener with these key/value pairs:\n\n"

    if not isSuccess then
        headerStatement = "TRANSACTION FAILED!\nA Corona networkEvent table was returned to the 'onFail' listener with these key/value pairs:\n\n"
    end

	local scrollView = widget.newScrollView({
		width = screenWidth - 100,
		height = screenHeight - 100,
		topPadding = 15,
		bottomPadding = 35,
		leftPadding = 15,
		rightPadding = 15,
		x = centerX,
		y = screenBottom + screenHeight,
		horizontalScrollDisabled = true,
	})
	scrollView:addEventListener("tap", function() return true end)
	foreground:insert(1, scrollView)

	local textObjects = {}
    local glyph = fontAwesome.check_circle_o
    if not isSuccess then glyph = fontAwesome.times_circle_o end
    local checkMark = display.newText({
        text = glyph,
        font = "FontAwesome",
        fontSize = 200,
        x = scrollView.width*.5,
        y = 20,
    })
    checkMark.anchorY = 0
    checkMark:setFillColor(0,1,0)
    table.insert(textObjects, checkMark)
    scrollView:insert(checkMark)

    local headerText = display.newText({
        text = headerStatement,
        width = scrollView.width - 60,
        font = "courier",
        fontSize = 16,
    })
    headerText.anchorX, headerText.anchorY = 0, 0
    headerText.x = 30
    headerText.y = textObjects[#textObjects].y + textObjects[#textObjects].height
    scrollView:insert(headerText)
    headerText:setFillColor(0, .5, 0)
    if not isSuccess then
        checkMark:setFillColor(1,0,0)
        headerText:setFillColor(1,0,0)
    end
    table.insert(textObjects, headerText)

	for i = 1, #results do
		local text = display.newText({
			text = results[i],
			width = scrollView.width - 60,
			font = "courier",
			fontSize = 16,
		})
		text.anchorX, text.anchorY = 0, 0
		text.x = 30
        text.y = textObjects[#textObjects].y + textObjects[#textObjects].height
		scrollView:insert(text)
		text:setFillColor(0)
		table.insert(textObjects, text)
	end

	local blackout = display.newRect(foreground, centerX, centerY, screenWidth, screenHeight)
	blackout:setFillColor(0, 0, 0, .6)
	blackout.alpha = 0
	blackout.isHitTestable = true

	local function closeResults()
		local function remove()
			display.remove(blackout)
			display.remove(scrollView)
			showButtons()
		end

		if blackout.alpha == 1 then
			blackout.tap = function() return true end
			transition.to(blackout, {alpha = 0})
			transition.to(scrollView, {y = screenBottom + screenHeight, time = 300, transition = easing.inOutSine, onComplete = remove})
		end
		return true
	end

	blackout.tap = closeResults
	blackout:addEventListener("tap")
	blackout:addEventListener("touch", function() return true end)

	local function part2()
		scrollView:toFront()
		transition.to(scrollView, {y = centerY, time = 300, transition = easing.inOutSine})
		transition.to(blackout, {alpha = 1})
	end

	transition.to(scrollView, {y = screenTop + screenHeight*.25, time = 800, transition = easing.inOutSine, onComplete = part2})
end

--------------------------------------------------------------------------------
-- GENERIC RESULT HANDLERS
--------------------------------------------------------------------------------
function _onSuccess(result, event)
    hideButtons()
    showResults(result, true)

    local printStatement = "****************************************\nTRANSACTION SUCCEEDED!\nA Stripe object table was returned to the 'onSuccess' listener with these key/value pairs:\n\n"
    for k,v in pairs(result) do
        printStatement = printStatement .. tostring(k) .. ": " .. tostring(v) .. "\n"
    end
    printStatement = printStatement .. "****************************************"
    print(printStatement)
end

function _onFail(event)
    hideButtons()
    showResults(event, false)

    local printStatement = "****************************************\nTRANSACTION FAILED!\nA Corona networkEvent table was returned to the 'onFail' listener with these key/value pairs:\n\n"
    for k,v in pairs(event) do
        printStatement = printStatement .. tostring(k) .. ": " .. tostring(v) .. "\n"
    end
    printStatement = printStatement .. "****************************************"
    print(printStatement)
end

function noData(endpoint, variableName, rowNum)
    native.showAlert(endpoint, "To call " .. endpoint .. " in the demo, you must supply a valid '" .. variableName .. "' variable, which you can define on line " .. tostring(rowNum) .. " of the demo project's main.lua.", {"OK"}, showButtons)
end

--------------------------------------------------------------------------------
-- PLUGIN FUNCTIONS:
--------------------------------------------------------------------------------
----------------------------------------
-- stripe.checkout()
----------------------------------------
function checkout()
    stripe.checkout({
        data = {
            image = "https://s3.amazonaws.com/stripe-uploads/acct_16wdTSELWHyjUdjWmerchant-icon-1445022594148-JS-Circle-Logo.png",
            name = "Stripe Plugin Demo",
            description = "stripe.checkout()",
        },
        amount = "100",
        currency = "usd",
        onSuccess = _onSuccess,
        onFail = _onFail,
        onCancel = showButtons,
        chargeNow = true,
    })
end

----------------------------------------
-- stripe.newCharge()
----------------------------------------
function newCharge()
    stripe.newCharge({
        amount = 50,
        currency = "usd",
        source = {
            exp_month = "01",
            exp_year = "20",
            number = "4242424242424242",
            object = "card",
            cvc = "123",
        },
        onSuccess = _onSuccess,
        onFail = _onFail,
    })
end

----------------------------------------
-- stripe.getCharge()
----------------------------------------
function getCharge()
    if getChargeID == "" or getChargeID == nil then
        noData("stripe.getCharge()", "getChargeID", 13)
    else
        stripe.getCharge({
            charge = getChargeID,
            onSuccess = _onSuccess,
            onFail = _onFail,
        })
    end
end

----------------------------------------
-- stripe.updateCharge()
----------------------------------------
function updateCharge()
    if updateChargeID == "" or updateChargeID == nil then
        noData("stripe.updateCharge()", "updateChargeID", 14)
    else
        stripe.updateCharge({
            charge = updateChargeID,
            description = "description updated " .. os.date("%c"),
            onSuccess = _onSuccess,
            onFail = _onFail,
        })
    end
end

----------------------------------------
-- stripe.captureCharge()
----------------------------------------
function captureCharge()
    if captureChargeID == "" or captureChargeID == nil then
        noData("stripe.captureCharge()", "captureChargeID", 15)
    else
        stripe.captureCharge({
            charge = captureChargeID,
            onSuccess = _onSuccess,
            onFail = _onFail,
        })
    end
end

----------------------------------------
-- stripe.listCharges()
----------------------------------------
function listCharges()
    stripe.listCharges({
        onSuccess = _onSuccess,
        onFail = _onFail,
    })
end

----------------------------------------
-- stripe.newCustomer()
----------------------------------------
function newCustomer()
    stripe.newCustomer({
        onSuccess = _onSuccess,
        onFail = _onFail,
    })
end

----------------------------------------
-- stripe.getCustomer()
----------------------------------------
function getCustomer()
    if getCustomerID == "" or getCustomerID == nil then
        noData("stripe.getCustomer()", "getCustomerID", 16)
    else
        stripe.getCustomer({
            customer = getCustomerID,
            onSuccess = _onSuccess,
            onFail = _onFail,
        })
    end
end

----------------------------------------
-- stripe.updateCustomer()
----------------------------------------
function updateCustomer()
    if updateCustomerID == "" or updateCustomerID == nil then
        noData("stripe.updateCustomer()", "updateCustomerID", 17)
    else
        stripe.updateCustomer({
            customer = updateCustomerID,
            description = "Jason Schroeder",
            onSuccess = _onSuccess,
            onFail = _onFail,
        })
    end
end

----------------------------------------
-- stripe.deleteCustomer()
----------------------------------------
function deleteCustomer()
    if deleteCustomerID == "" or deleteCustomerID == nil then
        noData("stripe.deleteCustomer()", "deleteCustomerID", 18)
    else
        stripe.deleteCustomer({
            customer = deleteCustomerID,
            onSuccess = _onSuccess,
            onFail = _onFail,
        })
    end
end

----------------------------------------
-- stripe.listCustomers()
----------------------------------------
function listCustomers()
    stripe.listCustomers({
        limit = 3,
        onSuccess = _onSuccess,
        onFail = _onFail,
    })
end

----------------------------------------
-- stripe.newToken()
----------------------------------------
function newToken()
    stripe.newToken({
        bank_account = {
            country = "US",
            currency = "usd",
            name = "Jason Schroeder",
            account_holder_type = "individual",
            routing_number = "110000000",
            account_number = "000123456789",
        },
        onSuccess = _onSuccess,
        onFail = _onFail,
    })
end

----------------------------------------
-- stripe.getToken()
----------------------------------------
function getToken()
    if getTokenID == "" or getTokenID == nil then
        noData("stripe.getToken()", "getTokenID", 19)
    else
        stripe.getToken({
            token = getTokenID,
            onSuccess = _onSuccess,
            onFail = _onFail,
        })
    end
end

----------------------------------------
-- stripe.donate()
----------------------------------------
function donate()
    local function goDonate()
        stripe.donate({
            amount = donateAmount,
            currency = "usd",
            onSuccess = _onSuccess,
            onFail = _onFail,
            onCancel = showButtons,
        })
    end

    local function alertListener2(event)
        if event.action == "clicked" then
            if event.index == 1 then
                goDonate()
            else
                showButtons()
            end
        end
    end

    local function alertListener(event)
        if event.action == "clicked" then
            if event.index == 1 then
                timer.performWithDelay(1, function()
                    native.showAlert("Just checking...", "If you proceed to checkout, a real charge for $" .. string.format("%.2f", donateAmount/100) .. " will be made to the card you enter. THIS IS NOT A TEST. Still want to continue?", {"Yes!", "No."}, alertListener2)
                end)
            else
                showButtons()
            end
        end
    end

    if donateAmount == "" or donateAmount == nil then
        noData("stripe.donate()", "donateAmount", 20)
    else
        native.showAlert("stripe.donate()", "stripe.donate() allows you to make a donation to the creator of the Stripe plugin. (You can adjust the donation amount on line 20 of this project's main.lua.) Want to continue?", {"Yes!", "No."}, alertListener)
    end
end

--------------------------------------------------------------------------------
-- SET UP GUI
--------------------------------------------------------------------------------
display.setStatusBar( display.HiddenStatusBar )
background = display.newGroup()
foreground = display.newGroup()
scrollView = widget.newScrollView({
    left = screenLeft,
    top = screenTop,
    height = screenHeight,
    width = screenWidth,
    verticalScrollDisabled = true,
    hideBackground = true,
    rightPadding = screenWidth*.125,
})
scrollView.alpha = 0

----------------------------------------
-- function to hide buttons
----------------------------------------
function hideButtons()
    for i = 1, #buttons do
        buttons[i]:setEnabled(false)
    end
    transition.to(scrollView, {y = screenBottom + centerY, alpha = 0, transition = easing.inOutSine})
end

----------------------------------------
-- function to show buttons
----------------------------------------
function showButtons()
    for i = 1, #buttons do
        buttons[i]:setEnabled(true)
    end
    transition.to(scrollView, {y = centerY, alpha = 1, transition = easing.inOutSine})
end

----------------------------------------
-- function to make buttons
----------------------------------------
function makeButton(image, text, func)
    local group = display.newGroup()

    local function buttonListener(event)
        local dist = math.abs(event.x - event.xStart)
        if dist > 25 then scrollView:takeFocus(event) end
        if event.phase == "ended" then
            hideButtons()
            func()
        end
    end

    local button = widget.newButton({
        shape = "roundedRect",
        width = 400,
        height = 300,
        x = 0,
        y = 0,
        cornerRadius = 30,
        label = image,
        font = "FontAwesome",
        fontSize = 150,
        labelYOffset = -25,
        fillColor = {default = {1, 1, 1, .7}, over = {0, .5, 1, .7}},
        labelColor = {default = {0, 0, 0, 1}, over = {0, 0, 0, 1}},
        strokeColor = {default = {0, 0, 0}, over = {0, 0, 0}},
        strokeWidth = 3,
        onEvent = buttonListener,
    })
    group:insert(button)

    local label = display.newText({
        parent = group,
        x = 0,
        y = 100,
        text = text,
        font = native.systemFont,
        fontSize = 32,
    })
    label:setFillColor(0)
    group.button = button
    button:setEnabled(false)

    return group
end

bg = display.newImage(background, "bg.jpg", true)
bg.anchorY = 1
bg.x, bg.y = centerX, centerY + bg.height*.5
background:insert(scrollView)

stripeLogo = display.newImageRect(background, "stripeLogo.png", 580, 246)
stripeLogo.x, stripeLogo.y = centerX, screenBottom
stripeLogo.xScale, stripeLogo.yScale = .01, .01
stripeLogo.alpha = 0
stripeLogo.rotation = math.random(-180, 180)

byline = display.newImageRect(background, "byline.png", 270, 70)
byline.x, byline.y = screenLeft, screenTop + 225
byline.anchorX, byline.anchorY = 1, 0
byline.alpha = 0

cards = display.newImage(foreground, "cards.png", true)
cards.x, cards.y = centerX, screenBottom + cards.height

local buttonList = {
    {"", "stripe.checkout()", checkout},
    {"", "stripe.newCharge()", newCharge},
    {"", "stripe.getCharge()", getCharge},
    {"", "stripe.updateCharge()", updateCharge},
    {"", "stripe.captureCharge()", captureCharge},
    {"", "stripe.listCharges()", listCharges},
    {"", "stripe.newCustomer()", newCustomer},
    {"", "stripe.getCustomer()", getCustomer},
    {"", "stripe.updateCustomer()", updateCustomer},
    {"", "stripe.deleteCustomer()", deleteCustomer},
    {"", "stripe.listCustomers()", listCustomers},
    {"", "stripe.newToken()", newToken},
    {"", "stripe.getToken()", getToken},
    {"", "stripe.donate()", donate},
}

for i = 1, #buttonList do
    local data = buttonList[i]
    local button = makeButton(data[1], data[2], data[3])
    button.x, button.y = screenLeft + 300 + (i-1)*450, centerY - screenTop
    scrollView:insert(button)
    buttons[i] = button.button
end

hideButtons()

scrollView:scrollTo('right', {onComplete = function()scrollView:scrollTo("left", {time = 3500, onComplete = showButtons})end})

--------------------------------------------------------------------------------
-- TRANSITION IN OBJECTS
--------------------------------------------------------------------------------
transition.to(bg, {y = screenBottom, time = 5000, transition = easing.inOutSine})
transition.to(stripeLogo, {y = screenTop + stripeLogo.height*.6, alpha = 1, transition = easing.outBack, xScale = 1, yScale = 1, time = 2000, rotation = 0})
transition.to(byline, {x = centerX + 40, alpha = 1, time = 1000, delay = 1500, transition = easing.inOutsine})
transition.to(cards, {y = screenBottom + screenTop, transition = easing.inOutSine, time = 2500})
transition.to(scrollView, {alpha = 1, transition = easing.inOutSine, time = 2500, y = centerY, delay = 1000})
