--[[
	 fontawesome v4.0.3
	 https://github.com/fortawesome/font-awesome
--]]
local fontAwesome = {}

-- .fa-glass
fontAwesome.glass = string.char(239, 128, 128)
-- .fa-music
fontAwesome.music = string.char(239, 128, 129)
-- .fa-search
fontAwesome.search = string.char(239, 128, 130)
-- .fa-envelope-o
fontAwesome.envelope_o = string.char(239, 128, 131)
-- .fa-heart
fontAwesome.heart = string.char(239, 128, 132)
-- .fa-star
fontAwesome.star = string.char(239, 128, 133)
-- .fa-star-o
fontAwesome.star_o = string.char(239, 128, 134)
-- .fa-user
fontAwesome.user = string.char(239, 128, 135)
-- .fa-film
fontAwesome.film = string.char(239, 128, 136)
-- .fa-th-large
fontAwesome.th_large = string.char(239, 128, 137)
-- .fa-th
fontAwesome.th = string.char(239, 128, 138)
-- .fa-th-list
fontAwesome.th_list = string.char(239, 128, 139)
-- .fa-check
fontAwesome.check = string.char(239, 128, 140)
-- .fa-times
fontAwesome.times = string.char(239, 128, 141)
-- .fa-search-plus
fontAwesome.search_plus = string.char(239, 128, 142)
-- .fa-search-minus
fontAwesome.search_minus = string.char(239, 128, 144)
-- .fa-power-off
fontAwesome.power_off = string.char(239, 128, 145)
-- .fa-signal
fontAwesome.signal = string.char(239, 128, 146)
-- .fa-cog
fontAwesome.cog = string.char(239, 128, 147)
-- .fa-trash-o
fontAwesome.trash_o = string.char(239, 128, 148)
-- .fa-home
fontAwesome.home = string.char(239, 128, 149)
-- .fa-file-o
fontAwesome.file_o = string.char(239, 128, 150)
-- .fa-clock-o
fontAwesome.clock_o = string.char(239, 128, 151)
-- .fa-road
fontAwesome.road = string.char(239, 128, 152)
-- .fa-download
fontAwesome.download = string.char(239, 128, 153)
-- .fa-arrow-circle-o-down
fontAwesome.arrow_circle_o_down = string.char(239, 128, 154)
-- .fa-arrow-circle-o-up
fontAwesome.arrow_circle_o_up = string.char(239, 128, 155)
-- .fa-inbox
fontAwesome.inbox = string.char(239, 128, 156)
-- .fa-play-circle-o
fontAwesome.play_circle_o = string.char(239, 128, 157)
-- .fa-repeat
fontAwesome.test = string.char(239, 128, 158)
-- .fa-refresh
fontAwesome.refresh = string.char(239, 128, 161)
-- .fa-list-alt
fontAwesome.list_alt = string.char(239, 128, 162)
-- .fa-lock
fontAwesome.lock = string.char(239, 128, 163)
-- .fa-flag
fontAwesome.flag = string.char(239, 128, 164)
-- .fa-headphones
fontAwesome.headphones = string.char(239, 128, 165)
-- .fa-volume-off
fontAwesome.volume_off = string.char(239, 128, 166)
-- .fa-volume-down
fontAwesome.volume_down = string.char(239, 128, 167)
-- .fa-volume-up
fontAwesome.volume_up = string.char(239, 128, 168)
-- .fa-qrcode
fontAwesome.qrcode = string.char(239, 128, 169)
-- .fa-barcode
fontAwesome.barcode = string.char(239, 128, 170)
-- .fa-tag
fontAwesome.tag = string.char(239, 128, 171)
-- .fa-tags
fontAwesome.tags = string.char(239, 128, 172)
-- .fa-book
fontAwesome.book = string.char(239, 128, 173)
-- .fa-bookmark
fontAwesome.bookmark = string.char(239, 128, 174)
-- .fa-print
fontAwesome.print = string.char(239, 128, 175)
-- .fa-camera
fontAwesome.camera = string.char(239, 128, 176)
-- .fa-font
fontAwesome.font = string.char(239, 128, 177)
-- .fa-bold
fontAwesome.bold = string.char(239, 128, 178)
-- .fa-italic
fontAwesome.italic = string.char(239, 128, 179)
-- .fa-text-height
fontAwesome.text_height = string.char(239, 128, 180)
-- .fa-text-width
fontAwesome.text_width = string.char(239, 128, 181)
-- .fa-align-left
fontAwesome.align_left = string.char(239, 128, 182)
-- .fa-align-center
fontAwesome.align_center = string.char(239, 128, 183)
-- .fa-align-right
fontAwesome.align_right = string.char(239, 128, 184)
-- .fa-align-justify
fontAwesome.align_justify = string.char(239, 128, 185)
-- .fa-list
fontAwesome.list = string.char(239, 128, 186)
-- .fa-outdent
fontAwesome.outdent = string.char(239, 128, 187)
-- .fa-indent
fontAwesome.indent = string.char(239, 128, 188)
-- .fa-video-camera
fontAwesome.video_camera = string.char(239, 128, 189)
-- .fa-picture-o
fontAwesome.picture_o = string.char(239, 128, 190)
-- .fa-pencil
fontAwesome.pencil = string.char(239, 129, 128)
-- .fa-map-marker
fontAwesome.map_marker = string.char(239, 129, 129)
-- .fa-adjust
fontAwesome.adjust = string.char(239, 129, 130)
-- .fa-tint
fontAwesome.tint = string.char(239, 129, 131)
-- .fa-pencil-square-o
fontAwesome.pencil_square_o = string.char(239, 129, 132)
-- .fa-share-square-o
fontAwesome.share_square_o = string.char(239, 129, 133)
-- .fa-check-square-o
fontAwesome.check_square_o = string.char(239, 129, 134)
-- .fa-arrows
fontAwesome.arrows = string.char(239, 129, 135)
-- .fa-step-backward
fontAwesome.step_backward = string.char(239, 129, 136)
-- .fa-fast-backward
fontAwesome.fast_backward = string.char(239, 129, 137)
-- .fa-backward
fontAwesome.backward = string.char(239, 129, 138)
-- .fa-play
fontAwesome.play = string.char(239, 129, 139)
-- .fa-pause
fontAwesome.pause = string.char(239, 129, 140)
-- .fa-stop
fontAwesome.stop = string.char(239, 129, 141)
-- .fa-forward
fontAwesome.forward = string.char(239, 129, 142)
-- .fa-fast-forward
fontAwesome.fast_forward = string.char(239, 129, 144)
-- .fa-step-forward
fontAwesome.step_forward = string.char(239, 129, 145)
-- .fa-eject
fontAwesome.eject = string.char(239, 129, 146)
-- .fa-chevron-left
fontAwesome.chevron_left = string.char(239, 129, 147)
-- .fa-chevron-right
fontAwesome.chevron_right = string.char(239, 129, 148)
-- .fa-plus-circle
fontAwesome.plus_circle = string.char(239, 129, 149)
-- .fa-minus-circle
fontAwesome.minus_circle = string.char(239, 129, 150)
-- .fa-times-circle
fontAwesome.times_circle = string.char(239, 129, 151)
-- .fa-check-circle
fontAwesome.check_circle = string.char(239, 129, 152)
-- .fa-question-circle
fontAwesome.question_circle = string.char(239, 129, 153)
-- .fa-info-circle
fontAwesome.info_circle = string.char(239, 129, 154)
-- .fa-crosshairs
fontAwesome.crosshairs = string.char(239, 129, 155)
-- .fa-times-circle-o
fontAwesome.times_circle_o = string.char(239, 129, 156)
-- .fa-check-circle-o
fontAwesome.check_circle_o = string.char(239, 129, 157)
-- .fa-ban
fontAwesome.ban = string.char(239, 129, 158)
-- .fa-arrow-left
fontAwesome.arrow_left = string.char(239, 129, 160)
-- .fa-arrow-right
fontAwesome.arrow_right = string.char(239, 129, 161)
-- .fa-arrow-up
fontAwesome.arrow_up = string.char(239, 129, 162)
-- .fa-arrow-down
fontAwesome.arrow_down = string.char(239, 129, 163)
-- .fa-share
fontAwesome.share = string.char(239, 129, 164)
-- .fa-expand
fontAwesome.expand = string.char(239, 129, 165)
-- .fa-compress
fontAwesome.compress = string.char(239, 129, 166)
-- .fa-plus
fontAwesome.plus = string.char(239, 129, 167)
-- .fa-minus
fontAwesome.minus = string.char(239, 129, 168)
-- .fa-asterisk
fontAwesome.asterisk = string.char(239, 129, 169)
-- .fa-exclamation-circle
fontAwesome.exclamation_circle = string.char(239, 129, 170)
-- .fa-gift
fontAwesome.gift = string.char(239, 129, 171)
-- .fa-leaf
fontAwesome.leaf = string.char(239, 129, 172)
-- .fa-fire
fontAwesome.fire = string.char(239, 129, 173)
-- .fa-eye
fontAwesome.eye = string.char(239, 129, 174)
-- .fa-eye-slash
fontAwesome.eye_slash = string.char(239, 129, 176)
-- .fa-exclamation-triangle
fontAwesome.exclamation_triangle = string.char(239, 129, 177)
-- .fa-plane
fontAwesome.plane = string.char(239, 129, 178)
-- .fa-calendar
fontAwesome.calendar = string.char(239, 129, 179)
-- .fa-random
fontAwesome.random = string.char(239, 129, 180)
-- .fa-comment
fontAwesome.comment = string.char(239, 129, 181)
-- .fa-magnet
fontAwesome.magnet = string.char(239, 129, 182)
-- .fa-chevron-up
fontAwesome.chevron_up = string.char(239, 129, 183)
-- .fa-chevron-down
fontAwesome.chevron_down = string.char(239, 129, 184)
-- .fa-retweet
fontAwesome.retweet = string.char(239, 129, 185)
-- .fa-shopping-cart
fontAwesome.shopping_cart = string.char(239, 129, 186)
-- .fa-folder
fontAwesome.folder = string.char(239, 129, 187)
-- .fa-folder-open
fontAwesome.folder_open = string.char(239, 129, 188)
-- .fa-arrows-v
fontAwesome.arrows_v = string.char(239, 129, 189)
-- .fa-arrows-h
fontAwesome.arrows_h = string.char(239, 129, 190)
-- .fa-bar-chart-o
fontAwesome.bar_chart_o = string.char(239, 130, 128)
-- .fa-twitter-square
fontAwesome.twitter_square = string.char(239, 130, 129)
-- .fa-facebook-square
fontAwesome.facebook_square = string.char(239, 130, 130)
-- .fa-camera-retro
fontAwesome.camera_retro = string.char(239, 130, 131)
-- .fa-key
fontAwesome.key = string.char(239, 130, 132)
-- .fa-cogs
fontAwesome.cogs = string.char(239, 130, 133)
-- .fa-comments
fontAwesome.comments = string.char(239, 130, 134)
-- .fa-thumbs-o-up
fontAwesome.thumbs_o_up = string.char(239, 130, 135)
-- .fa-thumbs-o-down
fontAwesome.thumbs_o_down = string.char(239, 130, 136)
-- .fa-star-half
fontAwesome.star_half = string.char(239, 130, 137)
-- .fa-heart-o
fontAwesome.heart_o = string.char(239, 130, 138)
-- .fa-sign-out
fontAwesome.sign_out = string.char(239, 130, 139)
-- .fa-linkedin-square
fontAwesome.linkedin_square = string.char(239, 130, 140)
-- .fa-thumb-tack
fontAwesome.thumb_tack = string.char(239, 130, 141)
-- .fa-external-link
fontAwesome.external_link = string.char(239, 130, 142)
-- .fa-sign-in
fontAwesome.sign_in = string.char(239, 130, 144)
-- .fa-trophy
fontAwesome.trophy = string.char(239, 130, 145)
-- .fa-github-square
fontAwesome.github_square = string.char(239, 130, 146)
-- .fa-upload
fontAwesome.upload = string.char(239, 130, 147)
-- .fa-lemon-o
fontAwesome.lemon_o = string.char(239, 130, 148)
-- .fa-phone
fontAwesome.phone = string.char(239, 130, 149)
-- .fa-square-o
fontAwesome.square_o = string.char(239, 130, 150)
-- .fa-bookmark-o
fontAwesome.bookmark_o = string.char(239, 130, 151)
-- .fa-phone-square
fontAwesome.phone_square = string.char(239, 130, 152)
-- .fa-twitter
fontAwesome.twitter = string.char(239, 130, 153)
-- .fa-facebook
fontAwesome.facebook = string.char(239, 130, 154)
-- .fa-github
fontAwesome.github = string.char(239, 130, 155)
-- .fa-unlock
fontAwesome.unlock = string.char(239, 130, 156)
-- .fa-credit-card
fontAwesome.credit_card = string.char(239, 130, 157)
-- .fa-rss
fontAwesome.rss = string.char(239, 130, 158)
-- .fa-hdd-o
fontAwesome.hdd_o = string.char(239, 130, 160)
-- .fa-bullhorn
fontAwesome.bullhorn = string.char(239, 130, 161)
-- .fa-bell
fontAwesome.bell = string.char(239, 131, 179)
-- .fa-certificate
fontAwesome.certificate = string.char(239, 130, 163)
-- .fa-hand-o-right
fontAwesome.hand_o_right = string.char(239, 130, 164)
-- .fa-hand-o-left
fontAwesome.hand_o_left = string.char(239, 130, 165)
-- .fa-hand-o-up
fontAwesome.hand_o_up = string.char(239, 130, 166)
-- .fa-hand-o-down
fontAwesome.hand_o_down = string.char(239, 130, 167)
-- .fa-arrow-circle-left
fontAwesome.arrow_circle_left = string.char(239, 130, 168)
-- .fa-arrow-circle-right
fontAwesome.arrow_circle_right = string.char(239, 130, 169)
-- .fa-arrow-circle-up
fontAwesome.arrow_circle_up = string.char(239, 130, 170)
-- .fa-arrow-circle-down
fontAwesome.arrow_circle_down = string.char(239, 130, 171)
-- .fa-globe
fontAwesome.globe = string.char(239, 130, 172)
-- .fa-wrench
fontAwesome.wrench = string.char(239, 130, 173)
-- .fa-tasks
fontAwesome.tasks = string.char(239, 130, 174)
-- .fa-filter
fontAwesome.filter = string.char(239, 130, 176)
-- .fa-briefcase
fontAwesome.briefcase = string.char(239, 130, 177)
-- .fa-arrows-alt
fontAwesome.arrows_alt = string.char(239, 130, 178)
-- .fa-users
fontAwesome.users = string.char(239, 131, 128)
-- .fa-link
fontAwesome.link = string.char(239, 131, 129)
-- .fa-cloud
fontAwesome.cloud = string.char(239, 131, 130)
-- .fa-flask
fontAwesome.flask = string.char(239, 131, 131)
-- .fa-scissors
fontAwesome.scissors = string.char(239, 131, 132)
-- .fa-files-o
fontAwesome.files_o = string.char(239, 131, 133)
-- .fa-paperclip
fontAwesome.paperclip = string.char(239, 131, 134)
-- .fa-floppy-o
fontAwesome.floppy_o = string.char(239, 131, 135)
-- .fa-square
fontAwesome.square = string.char(239, 131, 136)
-- .fa-bars
fontAwesome.bars = string.char(239, 131, 137)
-- .fa-list-ul
fontAwesome.list_ul = string.char(239, 131, 138)
-- .fa-list-ol
fontAwesome.list_ol = string.char(239, 131, 139)
-- .fa-strikethrough
fontAwesome.strikethrough = string.char(239, 131, 140)
-- .fa-underline
fontAwesome.underline = string.char(239, 131, 141)
-- .fa-table
fontAwesome.table = string.char(239, 131, 142)
-- .fa-magic
fontAwesome.magic = string.char(239, 131, 144)
-- .fa-truck
fontAwesome.truck = string.char(239, 131, 145)
-- .fa-pinterest
fontAwesome.pinterest = string.char(239, 131, 146)
-- .fa-pinterest-square
fontAwesome.pinterest_square = string.char(239, 131, 147)
-- .fa-google-plus-square
fontAwesome.google_plus_square = string.char(239, 131, 148)
-- .fa-google-plus
fontAwesome.google_plus = string.char(239, 131, 149)
-- .fa-money
fontAwesome.money = string.char(239, 131, 150)
-- .fa-caret-down
fontAwesome.caret_down = string.char(239, 131, 151)
-- .fa-caret-up
fontAwesome.caret_up = string.char(239, 131, 152)
-- .fa-caret-left
fontAwesome.caret_left = string.char(239, 131, 153)
-- .fa-caret-right
fontAwesome.caret_right = string.char(239, 131, 154)
-- .fa-columns
fontAwesome.columns = string.char(239, 131, 155)
-- .fa-sort
fontAwesome.sort = string.char(239, 131, 156)
-- .fa-sort-asc
fontAwesome.sort_asc = string.char(239, 131, 157)
-- .fa-sort-desc
fontAwesome.sort_desc = string.char(239, 131, 158)
-- .fa-envelope
fontAwesome.envelope = string.char(239, 131, 160)
-- .fa-linkedin
fontAwesome.linkedin = string.char(239, 131, 161)
-- .fa-undo
fontAwesome.undo = string.char(239, 131, 162)
-- .fa-gavel
fontAwesome.gavel = string.char(239, 131, 163)
-- .fa-tachometer
fontAwesome.tachometer = string.char(239, 131, 164)
-- .fa-comment-o
fontAwesome.comment_o = string.char(239, 131, 165)
-- .fa-comments-o
fontAwesome.comments_o = string.char(239, 131, 166)
-- .fa-bolt
fontAwesome.bolt = string.char(239, 131, 167)
-- .fa-sitemap
fontAwesome.sitemap = string.char(239, 131, 168)
-- .fa-umbrella
fontAwesome.umbrella = string.char(239, 131, 169)
-- .fa-clipboard
fontAwesome.clipboard = string.char(239, 131, 170)
-- .fa-lightbulb-o
fontAwesome.lightbulb_o = string.char(239, 131, 171)
-- .fa-exchange
fontAwesome.exchange = string.char(239, 131, 172)
-- .fa-cloud-download
fontAwesome.cloud_download = string.char(239, 131, 173)
-- .fa-cloud-upload
fontAwesome.cloud_upload = string.char(239, 131, 174)
-- .fa-user-md
fontAwesome.user_md = string.char(239, 131, 176)
-- .fa-stethoscope
fontAwesome.stethoscope = string.char(239, 131, 177)
-- .fa-suitcase
fontAwesome.suitcase = string.char(239, 131, 178)
-- .fa-bell-o
fontAwesome.bell_o = string.char(239, 130, 162)
-- .fa-coffee
fontAwesome.coffee = string.char(239, 131, 180)
-- .fa-cutlery
fontAwesome.cutlery = string.char(239, 131, 181)
-- .fa-file-text-o
fontAwesome.file_text_o = string.char(239, 131, 182)
-- .fa-building-o
fontAwesome.building_o = string.char(239, 131, 183)
-- .fa-hospital-o
fontAwesome.hospital_o = string.char(239, 131, 184)
-- .fa-ambulance
fontAwesome.ambulance = string.char(239, 131, 185)
-- .fa-medkit
fontAwesome.medkit = string.char(239, 131, 186)
-- .fa-fighter-jet
fontAwesome.fighter_jet = string.char(239, 131, 187)
-- .fa-beer
fontAwesome.beer = string.char(239, 131, 188)
-- .fa-h-square
fontAwesome.h_square = string.char(239, 131, 189)
-- .fa-plus-square
fontAwesome.plus_square = string.char(239, 131, 190)
-- .fa-angle-double-left
fontAwesome.angle_double_left = string.char(239, 132, 128)
-- .fa-angle-double-right
fontAwesome.angle_double_right = string.char(239, 132, 129)
-- .fa-angle-double-up
fontAwesome.angle_double_up = string.char(239, 132, 130)
-- .fa-angle-double-down
fontAwesome.angle_double_down = string.char(239, 132, 131)
-- .fa-angle-left
fontAwesome.angle_left = string.char(239, 132, 132)
-- .fa-angle-right
fontAwesome.angle_right = string.char(239, 132, 133)
-- .fa-angle-up
fontAwesome.angle_up = string.char(239, 132, 134)
-- .fa-angle-down
fontAwesome.angle_down = string.char(239, 132, 135)
-- .fa-desktop
fontAwesome.desktop = string.char(239, 132, 136)
-- .fa-laptop
fontAwesome.laptop = string.char(239, 132, 137)
-- .fa-tablet
fontAwesome.tablet = string.char(239, 132, 138)
-- .fa-mobile
fontAwesome.mobile = string.char(239, 132, 139)
-- .fa-circle-o
fontAwesome.circle_o = string.char(239, 132, 140)
-- .fa-quote-left
fontAwesome.quote_left = string.char(239, 132, 141)
-- .fa-quote-right
fontAwesome.quote_right = string.char(239, 132, 142)
-- .fa-spinner
fontAwesome.spinner = string.char(239, 132, 144)
-- .fa-circle
fontAwesome.circle = string.char(239, 132, 145)
-- .fa-reply
fontAwesome.reply = string.char(239, 132, 146)
-- .fa-github-alt
fontAwesome.github_alt = string.char(239, 132, 147)
-- .fa-folder-o
fontAwesome.folder_o = string.char(239, 132, 148)
-- .fa-folder-open-o
fontAwesome.folder_open_o = string.char(239, 132, 149)
-- .fa-smile-o
fontAwesome.smile_o = string.char(239, 132, 152)
-- .fa-frown-o
fontAwesome.frown_o = string.char(239, 132, 153)
-- .fa-meh-o
fontAwesome.meh_o = string.char(239, 132, 154)
-- .fa-gamepad
fontAwesome.gamepad = string.char(239, 132, 155)
-- .fa-keyboard-o
fontAwesome.keyboard_o = string.char(239, 132, 156)
-- .fa-flag-o
fontAwesome.flag_o = string.char(239, 132, 157)
-- .fa-flag-checkered
fontAwesome.flag_checkered = string.char(239, 132, 158)
-- .fa-terminal
fontAwesome.terminal = string.char(239, 132, 160)
-- .fa-code
fontAwesome.code = string.char(239, 132, 161)
-- .fa-reply-all
fontAwesome.reply_all = string.char(239, 132, 162)
-- .fa-mail-reply-all
fontAwesome.mail_reply_all = string.char(239, 132, 162)
-- .fa-star-half-o
fontAwesome.star_half_o = string.char(239, 132, 163)
-- .fa-location-arrow
fontAwesome.location_arrow = string.char(239, 132, 164)
-- .fa-crop
fontAwesome.crop = string.char(239, 132, 165)
-- .fa-code-fork
fontAwesome.code_fork = string.char(239, 132, 166)
-- .fa-chain-broken
fontAwesome.chain_broken = string.char(239, 132, 167)
-- .fa-question
fontAwesome.question = string.char(239, 132, 168)
-- .fa-info
fontAwesome.info = string.char(239, 132, 169)
-- .fa-exclamation
fontAwesome.exclamation = string.char(239, 132, 170)
-- .fa-superscript
fontAwesome.superscript = string.char(239, 132, 171)
-- .fa-subscript
fontAwesome.subscript = string.char(239, 132, 172)
-- .fa-eraser
fontAwesome.eraser = string.char(239, 132, 173)
-- .fa-puzzle-piece
fontAwesome.puzzle_piece = string.char(239, 132, 174)
-- .fa-microphone
fontAwesome.microphone = string.char(239, 132, 176)
-- .fa-microphone-slash
fontAwesome.microphone_slash = string.char(239, 132, 177)
-- .fa-shield
fontAwesome.shield = string.char(239, 132, 178)
-- .fa-calendar-o
fontAwesome.calendar_o = string.char(239, 132, 179)
-- .fa-fire-extinguisher
fontAwesome.fire_extinguisher = string.char(239, 132, 180)
-- .fa-rocket
fontAwesome.rocket = string.char(239, 132, 181)
-- .fa-maxcdn
fontAwesome.maxcdn = string.char(239, 132, 182)
-- .fa-chevron-circle-left
fontAwesome.chevron_circle_left = string.char(239, 132, 183)
-- .fa-chevron-circle-right
fontAwesome.chevron_circle_right = string.char(239, 132, 184)
-- .fa-chevron-circle-up
fontAwesome.chevron_circle_up = string.char(239, 132, 185)
-- .fa-chevron-circle-down
fontAwesome.chevron_circle_down = string.char(239, 132, 186)
-- .fa-html5
fontAwesome.html5 = string.char(239, 132, 187)
-- .fa-css3
fontAwesome.css3 = string.char(239, 132, 188)
-- .fa-anchor
fontAwesome.anchor = string.char(239, 132, 189)
-- .fa-unlock-alt
fontAwesome.unlock_alt = string.char(239, 132, 190)
-- .fa-bullseye
fontAwesome.bullseye = string.char(239, 133, 128)
-- .fa-ellipsis-h
fontAwesome.ellipsis_h = string.char(239, 133, 129)
-- .fa-ellipsis-v
fontAwesome.ellipsis_v = string.char(239, 133, 130)
-- .fa-rss-square
fontAwesome.rss_square = string.char(239, 133, 131)
-- .fa-play-circle
fontAwesome.play_circle = string.char(239, 133, 132)
-- .fa-ticket
fontAwesome.ticket = string.char(239, 133, 133)
-- .fa-minus-square
fontAwesome.minus_square = string.char(239, 133, 134)
-- .fa-minus-square-o
fontAwesome.minus_square_o = string.char(239, 133, 135)
-- .fa-level-up
fontAwesome.level_up = string.char(239, 133, 136)
-- .fa-level-down
fontAwesome.level_down = string.char(239, 133, 137)
-- .fa-check-square
fontAwesome.check_square = string.char(239, 133, 138)
-- .fa-pencil-square
fontAwesome.pencil_square = string.char(239, 133, 139)
-- .fa-external-link-square
fontAwesome.external_link_square = string.char(239, 133, 140)
-- .fa-share-square
fontAwesome.share_square = string.char(239, 133, 141)
-- .fa-compass
fontAwesome.compass = string.char(239, 133, 142)
-- .fa-caret-square-o-down
fontAwesome.caret_square_o_down = string.char(239, 133, 144)
-- .fa-caret-square-o-up
fontAwesome.caret_square_o_up = string.char(239, 133, 145)
-- .fa-caret-square-o-right
fontAwesome.caret_square_o_right = string.char(239, 133, 146)
-- .fa-eur
fontAwesome.eur = string.char(239, 133, 147)
-- .fa-gbp
fontAwesome.gbp = string.char(239, 133, 148)
-- .fa-usd
fontAwesome.usd = string.char(239, 133, 149)
-- .fa-inr
fontAwesome.inr = string.char(239, 133, 150)
-- .fa-jpy
fontAwesome.jpy = string.char(239, 133, 151)
-- .fa-rub
fontAwesome.rub = string.char(239, 133, 152)
-- .fa-krw
fontAwesome.krw = string.char(239, 133, 153)
-- .fa-btc
fontAwesome.btc = string.char(239, 133, 154)
-- .fa-file
fontAwesome.file = string.char(239, 133, 155)
-- .fa-file-text
fontAwesome.file_text = string.char(239, 133, 156)
-- .fa-sort-alpha-asc
fontAwesome.sort_alpha_asc = string.char(239, 133, 157)
-- .fa-sort-alpha-desc
fontAwesome.sort_alpha_desc = string.char(239, 133, 158)
-- .fa-sort-amount-asc
fontAwesome.sort_amount_asc = string.char(239, 133, 160)
-- .fa-sort-amount-desc
fontAwesome.sort_amount_desc = string.char(239, 133, 161)
-- .fa-sort-numeric-asc
fontAwesome.sort_numeric_asc = string.char(239, 133, 162)
-- .fa-sort-numeric-desc
fontAwesome.sort_numeric_desc = string.char(239, 133, 163)
-- .fa-thumbs-up
fontAwesome.thumbs_up = string.char(239, 133, 164)
-- .fa-thumbs-down
fontAwesome.thumbs_down = string.char(239, 133, 165)
-- .fa-youtube-square
fontAwesome.youtube_square = string.char(239, 133, 166)
-- .fa-youtube
fontAwesome.youtube = string.char(239, 133, 167)
-- .fa-xing
fontAwesome.xing = string.char(239, 133, 168)
-- .fa-xing-square
fontAwesome.xing_square = string.char(239, 133, 169)
-- .fa-youtube-play
fontAwesome.youtube_play = string.char(239, 133, 170)
-- .fa-dropbox
fontAwesome.dropbox = string.char(239, 133, 171)
-- .fa-stack-overflow
fontAwesome.stack_overflow = string.char(239, 133, 172)
-- .fa-instagram
fontAwesome.instagram = string.char(239, 133, 173)
-- .fa-flickr
fontAwesome.flickr = string.char(239, 133, 174)
-- .fa-adn
fontAwesome.adn = string.char(239, 133, 176)
-- .fa-bitbucket
fontAwesome.bitbucket = string.char(239, 133, 177)
-- .fa-bitbucket-square
fontAwesome.bitbucket_square = string.char(239, 133, 178)
-- .fa-tumblr
fontAwesome.tumblr = string.char(239, 133, 179)
-- .fa-tumblr-square
fontAwesome.tumblr_square = string.char(239, 133, 180)
-- .fa-long-arrow-down
fontAwesome.long_arrow_down = string.char(239, 133, 181)
-- .fa-long-arrow-up
fontAwesome.long_arrow_up = string.char(239, 133, 182)
-- .fa-long-arrow-left
fontAwesome.long_arrow_left = string.char(239, 133, 183)
-- .fa-long-arrow-right
fontAwesome.long_arrow_right = string.char(239, 133, 184)
-- .fa-apple
fontAwesome.apple = string.char(239, 133, 185)
-- .fa-windows
fontAwesome.windows = string.char(239, 133, 186)
-- .fa-android
fontAwesome.android = string.char(239, 133, 187)
-- .fa-linux
fontAwesome.linux = string.char(239, 133, 188)
-- .fa-dribbble
fontAwesome.dribbble = string.char(239, 133, 189)
-- .fa-skype
fontAwesome.skype = string.char(239, 133, 190)
-- .fa-foursquare
fontAwesome.foursquare = string.char(239, 134, 128)
-- .fa-trello
fontAwesome.trello = string.char(239, 134, 129)
-- .fa-female
fontAwesome.female = string.char(239, 134, 130)
-- .fa-male
fontAwesome.male = string.char(239, 134, 131)
-- .fa-gittip
fontAwesome.gittip = string.char(239, 134, 132)
-- .fa-sun-o
fontAwesome.sun_o = string.char(239, 134, 133)
-- .fa-moon-o
fontAwesome.moon_o = string.char(239, 134, 134)
-- .fa-archive
fontAwesome.archive = string.char(239, 134, 135)
-- .fa-bug
fontAwesome.bug = string.char(239, 134, 136)
-- .fa-vk
fontAwesome.vk = string.char(239, 134, 137)
-- .fa-weibo
fontAwesome.weibo = string.char(239, 134, 138)
-- .fa-renren
fontAwesome.renren = string.char(239, 134, 139)
-- .fa-pagelines
fontAwesome.pagelines = string.char(239, 134, 140)
-- .fa-stack-exchange
fontAwesome.stack_exchange = string.char(239, 134, 141)
-- .fa-arrow-circle-o-right
fontAwesome.arrow_circle_o_right = string.char(239, 134, 142)
-- .fa-arrow-circle-o-left
fontAwesome.arrow_circle_o_left = string.char(239, 134, 144)
-- .fa-caret-square-o-left
fontAwesome.caret_square_o_left = string.char(239, 134, 145)
-- .fa-dot-circle-o
fontAwesome.dot_circle_o = string.char(239, 134, 146)
-- .fa-wheelchair
fontAwesome.wheelchair = string.char(239, 134, 147)
-- .fa-vimeo-square
fontAwesome.vimeo_square = string.char(239, 134, 148)
-- .fa-try
fontAwesome.try = string.char(239, 134, 149)
-- .fa-plus-square-o
fontAwesome.plus_square_o = string.char(239, 134, 150)

return fontAwesome
