application = {
	showRuntimeErrors = false,
	content = {
		width = 768,
		height = 1024, 
		scale = "letterBox",
		fps = 60,
		imageSuffix = {["@2x"] = 1.5}
	},
	license = {
		google = {
			key = "",
		},
	},
}